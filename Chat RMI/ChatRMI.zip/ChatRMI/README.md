# ChatRMI

**Trabalho realizado na disciplina de Sistemas Distribuidos do Curso de Engenharia de Computação UTFPR campus Santa Helena.**
Cristiano Koxne
Wesley Augusto Catuzzo de Bona
Geferson Artuzo

1. Autenticação criptografada

2. Cadastro (email/username/senha)

3. Lista de usuários conectados

4. Chat privado

5. Envio de arquivos

6. Servidor pode banir e aceitar novamente um usuário. 
